class SortingMachine {
    void sort(Relatable[] p){
      for (int i = 0; i < p.length; i++){
        Relatable key = p[i];
        int  j = i - 1;
        while(j >= 0 && key.isSmallerThan(p[j])) {
          p[j + 1] = p[j];
          j--;
        }
        p[j + 1] = key;
      }
    }
}
